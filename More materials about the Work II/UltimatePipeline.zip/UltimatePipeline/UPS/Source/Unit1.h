//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include <ActnList.hpp>
#include <StdActns.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TMenuItem *Relatrio1;
        TMenuItem *Imprimir1;
        TMenuItem *Sair1;
        TGroupBox *GroupBox1;
        TRichEdit *RichEdit1;
        TGroupBox *GroupBox2;
        TGroupBox *GroupBox3;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TGroupBox *GroupBox4;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TRichEdit *RichEdit3;
        TRichEdit *RichEdit2;
        TLabel *Label16;
        TLabel *Label17;
        TMenuItem *Salvar1;
        TSaveDialog *SaveDialog1;
        TLabel *Label6;
        TRichEdit *RichEdit4;
        void __fastcall Imprimir1Click(TObject *Sender);
        void __fastcall Sair1Click(TObject *Sender);
        void __fastcall Salvar1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
