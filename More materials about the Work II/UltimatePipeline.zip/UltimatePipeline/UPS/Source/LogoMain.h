//----------------------------------------------------------------------------
#ifndef LogoMainH
#define LogoMainH
//----------------------------------------------------------------------------
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Dialogs.hpp>
#include <vcl\Menus.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>
#include <DBCtrls.hpp>
#include <CheckLst.hpp>
#include <FileCtrl.hpp>
#include "CGAUGES.h"
//----------------------------------------------------------------------------
class TLogoAppForm : public TForm
{
__published:
	TOpenDialog *OpenDialog;
	TSaveDialog *SaveDialog;
        TToolBar *ToolBar1;
        TToolButton *ToolButton1;
        TToolButton *ToolButton2;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TToolButton *ToolButton5;
        TToolButton *ToolButton6;
        TToolButton *ToolButton9;
        TActionList *ActionList1;
        TAction *FileNew1;
        TAction *FileOpen1;
        TAction *FileSave1;
        TAction *FileSaveAs1;
        TAction *FileSend1;
        TAction *FileExit1;
        TEditCut *EditCut1;
        TEditCopy *EditCopy1;
        TEditPaste *EditPaste1;
        TAction *HelpAbout1;
        TStatusBar *StatusBar;
        TImageList *ImageList1;
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *FileNewItem;
        TMenuItem *FileOpenItem;
        TMenuItem *FileSaveItem;
        TMenuItem *FileSaveAsItem;
        TMenuItem *FileExitItem;
        TMenuItem *CutItem;
        TMenuItem *CopyItem;
        TMenuItem *PasteItem;
        TMenuItem *Help1;
        TMenuItem *HelpAboutItem;
        TGroupBox *GroupBox1;
        TGroupBox *GroupBox2;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *Edit2;
        TEdit *Edit3;
        TLabel *Label3;
        TLabel *Label4;
        TGroupBox *GroupBox3;
        TCheckBox *CheckBox1;
        TCheckBox *CheckBox2;
        TCheckBox *CheckBox3;
        TGroupBox *GroupBox4;
        TButton *Button2;
        TButton *Button4;
        TButton *Button5;
        TButton *Button1;
        TGroupBox *GroupBox5;
        TGroupBox *GroupBox6;
        TGroupBox *GroupBox7;
        TGroupBox *GroupBox8;
        TGroupBox *GroupBox9;
        TGroupBox *GroupBox10;
        TEdit *Edit4;
        TEdit *Edit5;
        TEdit *Edit6;
        TEdit *Edit7;
        TEdit *Edit8;
        TButton *Button3;
        TTrackBar *TrackBar1;
        TLabel *Label5;
        TLabel *Label6;
        TMenuItem *Linguagem1;
        TMenuItem *PortugusBR1;
        TMenuItem *EnglishUS1;
        TMenuItem *Editt;
        TGroupBox *GroupBox11;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TImage *Image1;
        TImage *Image2;
        TImage *Image4;
        TImage *Image5;
        TImage *Image7;
        TImage *Image8;
        TImage *Image10;
        TImage *Image12;
        TImage *Image14;
        TImage *Image15;
        TImage *Image16;
        TImage *Image18;
        TToolButton *ToolButton7;
        TRichEdit *RichEdit1;
        TLabel *Label21;
        TLabel *Label22;
        TCGauge *CGauge1;
        TButton *Button6;
        TLabel *Label12;
        TImage *Image3;
        TImage *Image6;
        TImage *Image9;
        TImage *Image11;
        TImage *Image13;
        TImage *Image17;
	void __fastcall FileNew1Execute(TObject *Sender);
	void __fastcall FileOpen1Execute(TObject *Sender);
	void __fastcall FileSave1Execute(TObject *Sender);
	void __fastcall FileSaveAs1Execute(TObject *Sender);
	void __fastcall FileSend1Execute(TObject *Sender);
	void __fastcall FileExit1Execute(TObject *Sender);
	void __fastcall HelpAbout1Execute(TObject *Sender);
        void __fastcall PortugusBR1Click(TObject *Sender);
        void __fastcall EnglishUS1Click(TObject *Sender);
        void __fastcall TrackBar1Change(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall ToolButton7Click(TObject *Sender);
        void __fastcall Button5Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button6Click(TObject *Sender);
        void __fastcall Edit2Change(TObject *Sender);
        void __fastcall Edit3Change(TObject *Sender);
        void __fastcall Edit2KeyPress(TObject *Sender, char &Key);
        void __fastcall Edit3KeyPress(TObject *Sender, char &Key);
private:
	AnsiString FFileName;
public:
	virtual __fastcall TLogoAppForm(TComponent *Owner);
};
//----------------------------------------------------------------------------
extern TLogoAppForm *LogoAppForm;
//----------------------------------------------------------------------------
#endif    
