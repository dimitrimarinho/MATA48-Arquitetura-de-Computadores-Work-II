//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------
USEFORM("LogoMain.cpp", LogoAppForm);
USERC("LogoStrs.rc");
USERES("LogoApp.res");
USEFORM("About.cpp", AboutBox);
USEFORM("Unit1.cpp", Form1);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	Application->Initialize();
	Application->CreateForm(__classid(TLogoAppForm), &LogoAppForm);
      Application->CreateForm(__classid(TAboutBox), &AboutBox);
      Application->CreateForm(__classid(TForm1), &Form1);

                 Application->Run();

	return 0;  
}
//---------------------------------------------------------------------
