/************************************************************************
 *       Ultimate Pipeline Simulator: Simulador do Pipeline do MIPS     *
 *                                                                      *
 *  Pontif�cia Universidade cat�lica de Minhas Gerais                   *
 *  Disciplina: Arquitetura de Computadores III                         *
 *                                                                      *
 *  Software vers�o: 1.0                                                *	                                                                    *
 *  Programadores: C�zar da Cunha Barcellos(1)                          *
 *                 Henrique Magalh�es Sim�es(2)                         *                                                                    *
 *  Contato: cezar.opaleiro@gmail.com(1)                                *
 *           henriquems@gmail.com(2)                                    *
 *  Data: 10/06/2009                                                    *
 ************************************************************************/


//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <iostream.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include "About.h"
#include "LogoMain.h"
#include "LogoStrs.h"
#include "MAPI.hpp"
#include "Unit1.h"
#include <Classes.hpp>
#include<mmsystem.h>
#define T1H


#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"

//---------------------------------------------------------------------------


int Distancia, DependenciaRAW, tamanho = 0, N=0, Jump =0, Velocidade, BBolhas=0, CClock=1, w=0,b=0, Terminou =0,ErrLinha, idx =0,pos = 0, pos2 = 0;
int maxi =0,flag_counter =0;
int para_retoma = 0;
int FLASH = 0;
bool SW, AUX = false, BarraR = false, APAGAR2 = false,APAGAR3 = false, FLAGCLOCK = false;
String AUX2 = "false";
String AUX3 = "false";
String Direcao, mode;
String local, local2;
String Bubble = "BOLHA";
String SemiTitulo = "Relat�rio Final", rodape = "Fim do relat�rio.", adiantamentos = "Nenhum adiantamento foi ativado!",Continuar = "Continuar";
AnsiString Mensagem1= "Erro L�xico no c�digo Assembler!",Mensagem2= "Erro Sint�tico no c�digo Assembler!",Mensagem3= "Aten��o, arquivo em branco.",Mensagem4="Erro! Registrador sem identificador ou formato inv�lido.",Mensagem5 = "Aten��o! Somente digitos.",Mensagem6 = "Erro Sint�tico! Instru��o (LW ou SW) faltando ')'",Mensagem7,Mensagem8, Linha = "Linha";


struct Item{

  AnsiString id;
  AnsiString reg1;
  AnsiString reg2;
  AnsiString reg3;
  AnsiString add1On;
  AnsiString add2On;
  AnsiString add3On;
  int idx;
};

struct Nodo{
Item I;
struct Nodo *Esq, *Dir;
};

class Lista{

public:
int tamanho;
bool STEP, STOP;


AnsiString pipe, pipe2, pipe3;
int BolhasRAW, ciclos, NUMDEP;
Nodo *Primeiro,*Ultimo;
String SDependencias;
Lista(void);
int Vazia(void);
void Inserir(Item Elemento);
~Lista();
void Dependencias(Lista *L);
void UnidadeControle(Lista *L);
void ReIndexar(Lista *L );
void InserePosicao(Nodo *posicao, Lista &L, Item Elemento);
int  Indice(String instrucao, Lista *L );
Nodo* BuscaPosicao (String posicao, Lista &L);
int GetIndice (String posicao, Lista &L);
};


Lista :: Lista(void){

   if((Primeiro=Ultimo = new(Nodo)) == NULL){
   ShowMessage("Sem mem�ria!");
   }
	else
	{
        tamanho = 0;
	Primeiro->I.id =0;
	Primeiro->Esq = Primeiro->Dir = NULL;
	}

}

int Lista :: Vazia(void){
return(Primeiro == Ultimo);
}

void Lista :: Inserir(Item Elemento){
  if((Ultimo->Dir = new(Nodo))==NULL){
  ShowMessage("Sem mem�ria!");
  }
	else{
        tamanho++;
        idx++;
	Ultimo->Dir->Esq = Ultimo;
	Ultimo = Ultimo->Dir;
	Ultimo->Dir = NULL;
	Ultimo->I = Elemento;
        Ultimo->I.idx = idx;
        }
}

Lista :: ~Lista(){
Nodo *Temp = Primeiro->Dir;
Nodo *Temp2 = NULL;
        while(Temp){
          Temp2 = Temp->Dir;
          delete Temp;
          Temp = Temp2;
        }

        Temp = NULL;
        Temp2= NULL;
        tamanho=0;

}

void Lista :: Dependencias(Lista *L){
Nodo *Temp, *Temp2;
int cont1=1, cont2=2;
NUMDEP =0;

SDependencias = "";

Temp  = L->Primeiro->Dir;
Temp2 = L->Primeiro->Dir;
    while(Temp->Dir != NULL){

        if(Temp == L->Ultimo){
        Temp = NULL;
        }
        if(Temp->I.id != "sw" && Temp->I.id != "SW"){


                     while(Temp2 != NULL){


                if(Temp2 == Ultimo){
                   Temp2 = NULL;

                   }
                     else{

                      if(Temp2->Dir != NULL){

                      }

                      if(Temp2 == L->Ultimo){
                      Temp2 = NULL;
                      }


                        if(Temp2->Dir->I.id != "sw" && Temp2->Dir->I.id != "SW"){


                           if(Temp->I.reg1 == Temp2->Dir->I.reg2 || Temp->I.reg1 == Temp2->Dir->I.reg3 ){

                               if(Temp->I.reg1 == Temp2->Dir->I.reg2){
                               SDependencias = SDependencias+"DEP( "+IntToStr(cont1)+","+IntToStr(cont2)+" )"+" - "+Temp->I.reg1+"\n";
                               NUMDEP++;
                               }
                               if(Temp->I.reg1 == Temp2->Dir->I.reg3){
                               SDependencias = SDependencias+"DEP( "+IntToStr(cont1)+","+IntToStr(cont2)+" )"+" - "+Temp->I.reg1+"\n";
                               NUMDEP++;
                               }
                            }

                           if(Temp->I.reg1 == Temp2->Dir->I.reg1){
                           Temp2 = NULL;

                           }

                        }
                        else{



                            if(Temp->I.reg1 == Temp2->Dir->I.reg1 || Temp->I.reg1 == Temp2->Dir->I.reg2 || Temp->I.reg1 == Temp2->Dir->I.reg3 && Temp->I.reg1 != Temp2->Dir->I.reg1){


                               if(Temp->I.reg1 == Temp2->Dir->I.reg1){
                               SDependencias = SDependencias+"DEP( "+IntToStr(cont1)+","+IntToStr(cont2)+" )"+" - "+Temp->I.reg1+"\n";
                               NUMDEP++;
                               }
                               if(Temp->I.reg1 == Temp2->Dir->I.reg2){
                               SDependencias = SDependencias+"DEP( "+IntToStr(cont1)+","+IntToStr(cont2)+" )"+" - "+Temp->I.reg1+"\n";
                               NUMDEP++;
                               }
                               if(Temp->I.reg1 == Temp2->Dir->I.reg3){
                               SDependencias = SDependencias+"DEP( "+IntToStr(cont1)+","+IntToStr(cont2)+" )"+" - "+Temp->I.reg1+"\n";
                               NUMDEP++;
                               }
                            }

                            if(Temp->I.reg1 == Temp2->Dir->I.reg1 && Temp2->Dir->I.id != "sw" && Temp2->Dir->I.id != "SW"){
                            Temp2 = NULL;

                            }

                   }

                            if(Temp2 != Ultimo){
                            cont2++;
                            }
                            if(Temp2 != NULL){
                            Temp2 = Temp2->Dir;
                            }


            } //while temp2
        }//if
    }
            cont1++;
            cont2 = cont1+1;
            if(Temp != NULL){
            Temp = Temp->Dir;
            Temp2 = Temp;
            }
       } //while  temp

}

void Lista :: UnidadeControle(Lista *L){
Nodo *Temp;
Item Bolha;
Bolha.id = Bubble;
AUX = false;
BolhasRAW = 0;
bool LW_SW = false;


Temp = L->Primeiro->Dir;
    while(Temp != NULL){



    if(Temp == L->Ultimo){
    Temp = NULL;
    }

    else{

        if(Temp == L->Ultimo->Esq || Temp->I.id == Bubble){


                 if(Temp->Dir->I.id == "sw" || Temp->Dir->I.id== "SW" ){
                 SW = true;

                 }
                          if(SW == true){



                          if((Temp->I.id == "lw" || Temp->I.id == "LW") && (Temp->Dir->I.id == "sw" || Temp->Dir->I.id == "SW")){//IF4
                          LW_SW = true;

                                if(Temp->I.reg1 == Temp->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3){//IF5
                                            Distancia = 1;
                                            if(LogoAppForm->CheckBox3->Checked == false && LogoAppForm->CheckBox2->Checked == true){
                                            L->InserePosicao(Temp,*L,Bolha); //insere bolha
                                            BolhasRAW++;

                                            }
                                            else if(LogoAppForm->CheckBox3->Checked == false){

                                                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                                                 BolhasRAW++;
                                                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                                                 BolhasRAW++;
                                            }
                                            if(LogoAppForm->CheckBox3->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir != NULL){
                                            Temp->I.add3On = "ON";
                                            }

                                 }

                          }//conflito LW->SW


            if(Temp->I.reg1 == Temp->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3 && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){//IF4

              if((Temp->I.reg1 == Temp->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){//IF5
               Distancia = 1;

               if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == false && ( Temp->I.id == "LW" || Temp->I.id == "lw") && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                else if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == true && ( Temp->I.id == "LW" || Temp->I.id == "lw") && LW_SW != true){

                L->InserePosicao(Temp,*L,Bolha); //insere bolha
                BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LogoAppForm->CheckBox3->Checked == true  && Temp->Dir->I.id != "SW" && Temp->Dir->I.id != "sw"){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LW_SW != true){  //adiantamento 1

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 }
                 if(LogoAppForm->CheckBox1->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP"&& Temp->Dir != NULL){
                 Temp->Dir->I.add1On = "ON";
                 }
               }

             }
          }
          if(Temp->Dir->Dir != NULL){
             if((Temp->I.reg1 == Temp->Dir->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
             Distancia = 2;

               if(LogoAppForm->CheckBox2->Checked == false ){

               L->InserePosicao(Temp->Dir,*L,Bolha);   //insere bolha
               BolhasRAW++;
               }

               if(LogoAppForm->CheckBox2->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir->Dir != NULL){

                 Temp->Dir->Dir->I.add2On = "ON";
                 }

              }
          }




       if(Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3){

                if((Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
                Distancia = 1;
                if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == false && ( Temp->I.id == "LW" || Temp->I.id == "lw")&& LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                else if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == true && ( Temp->I.id == "LW" || Temp->I.id == "lw") && LW_SW != true){

                L->InserePosicao(Temp,*L,Bolha); //insere bolha
                BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LogoAppForm->CheckBox3->Checked == true && Temp->Dir->I.id != "SW" && Temp->Dir->I.id != "sw"){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LW_SW != true){  //adiantamento 1

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 }
                 if(LogoAppForm->CheckBox1->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir != NULL){

                 Temp->Dir->I.add1On = "ON";
                 }

                }
    if(Temp != Ultimo->Esq || Temp != Ultimo && Temp->Dir->Dir != NULL){
      if((Temp->I.reg1 == Temp->Dir->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
            Distancia = 2;

                if(LogoAppForm->CheckBox2->Checked == false ){

                L->InserePosicao(Temp->Dir,*L,Bolha);   //insere bolha
                BolhasRAW++;
                }
                if(LogoAppForm->CheckBox2->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir->Dir != NULL){

                Temp->Dir->Dir->I.add2On = "ON";
                }

      }
    }

   }

       Temp = Temp->Dir;
       SW = false;
       LW_SW = false;
      }

  else{


       if(Temp->Dir->I.id == "sw" || Temp->Dir->I.id== "SW" || Temp->Dir->Dir->I.id == "sw" || Temp->Dir->Dir->I.id== "SW"){
       SW = true;
       }
       if(SW == true){


             if((Temp->I.id == "lw" || Temp->I.id == "LW") && (Temp->Dir->I.id == "sw" || Temp->Dir->I.id == "SW") ){
                          LW_SW = true;

                                if(Temp->I.reg1 == Temp->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3){//IF5
                                            Distancia = 1;
                                            if(LogoAppForm->CheckBox3->Checked == false && LogoAppForm->CheckBox2->Checked == true){

                                            L->InserePosicao(Temp,*L,Bolha); //insere bolha
                                            BolhasRAW++;

                                            }
                                            else if(LogoAppForm->CheckBox3->Checked == false){

                                                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                                                 BolhasRAW++;
                                                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                                                 BolhasRAW++;
                                            }
                                            if(LogoAppForm->CheckBox3->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir != NULL){
                                            Temp->I.add3On = "ON";
                                            }

                                 }

             }//conflito LW->SW


        if(Temp->I.reg1 == Temp->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3
        || Temp->I.reg1 == Temp->Dir->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->Dir->I.reg3 && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){

            if((Temp->I.reg1 == Temp->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
            Distancia = 1;


                if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == false && ( Temp->I.id == "LW" || Temp->I.id == "lw") && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                else if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == true && ( Temp->I.id == "LW" || Temp->I.id == "lw") && LW_SW != true){

                L->InserePosicao(Temp,*L,Bolha); //insere bolha
                BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LogoAppForm->CheckBox3->Checked == true && Temp->Dir->I.id != "SW" && Temp->Dir->I.id != "sw"){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 }

                 if(LogoAppForm->CheckBox1->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir != NULL){
                 Temp->Dir->I.add1On = "ON";
                 }

            }

        }

       if((Temp->I.reg1 == Temp->Dir->Dir->I.reg1 || Temp->I.reg1 == Temp->Dir->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
       Distancia = 2;

               if(LogoAppForm->CheckBox2->Checked == false){

               L->InserePosicao(Temp->Dir,*L,Bolha);   //insere bolha
               BolhasRAW++;
               }
               if(LogoAppForm->CheckBox2->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir->Dir != NULL){
               Temp->Dir->Dir->I.add2On = "ON";
               }
       }

       }
       else if(Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3
            || Temp->I.reg1 == Temp->Dir->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->Dir->I.reg3 && Temp->I.id != "sw" &&  Temp->I.id != "SW"  ){

                if((Temp->I.reg1 == Temp->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
                Distancia = 1;

                   if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == false && ( Temp->I.id == "LW" || Temp->I.id == "lw")&& LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                else if(LogoAppForm->CheckBox1->Checked == true && LogoAppForm->CheckBox2->Checked == true && ( Temp->I.id == "LW" || Temp->I.id == "lw") && LW_SW != true){

                L->InserePosicao(Temp,*L,Bolha); //insere bolha
                BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == true && LogoAppForm->CheckBox3->Checked == true  && Temp->Dir->I.id != "SW" && Temp->Dir->I.id != "sw"){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                }
                 else if(LogoAppForm->CheckBox1->Checked == false && LW_SW != true){

                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 L->InserePosicao(Temp,*L,Bolha); //insere bolha
                 BolhasRAW++;
                 }
                 if(LogoAppForm->CheckBox1->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir != NULL){

                 Temp->Dir->I.add1On = "ON";
                 }

       }

                if((Temp->I.reg1 == Temp->Dir->Dir->I.reg2 || Temp->I.reg1 == Temp->Dir->Dir->I.reg3) && Temp->I.id != Bubble && Temp->I.id != "sw" &&  Temp->I.id != "SW" ){
                Distancia = 2;

                     if(LogoAppForm->CheckBox2->Checked == false ){

                     L->InserePosicao(Temp->Dir,*L,Bolha); //insere bolha
                     BolhasRAW++;

                     }
                     if(LogoAppForm->CheckBox2->Checked == true && Temp->I.id !=Bubble && Temp->I.id !="NOP" && Temp->Dir->Dir != NULL){
                     Temp->Dir->Dir->I.add2On = "ON";
                     }

                }
        }

        Temp = Temp->Dir;

  }
 }
}
SW = false;
LW_SW = false;
ciclos = tamanho+4;
}
void Lista :: ReIndexar(Lista *L ){
 Nodo *x;
 String TESTTT;
 int index = 1;
    if ( !Vazia()){
     x = L->Primeiro->Dir;
    }
    while(x != NULL){
    x->I.idx = index;
    x = x->Dir;
    index++;
    }
}


void Lista :: InserePosicao (Nodo *posicao, Lista &L, Item Elemento)
{
   AnsiString aux;
   int count = 1;
    Nodo *x,*k;
    if ( !Vazia()){

        x = L.Primeiro->Dir;

    }

    while (x != posicao ){
        x = x->Dir;

    }


            Nodo *y = new Nodo();
            tamanho++;
            y->Dir = x->Dir;
            y->Esq = x;
            x->Dir = y;

            if(y->Dir == NULL){
	    L.Ultimo = y;
            }
	    else{
	    y->Dir->Esq = y;
            }
            y->I = Elemento;
            ReIndexar(&L);
             pipe ="";
             pipe2="";
            k = L.Primeiro->Dir;
            while(k != NULL){

             pipe = pipe+k->I.id+"\n";


            if(k->I.id == "lw" || k->I.id == "LW" || k->I.id == "sw" || k->I.id == "SW" && k->I.id != "NOP"){
            aux = "[ "+IntToStr(k->I.idx)+" ] "+k->I.id+" "+k->I.reg1+","+k->I.reg2+"("+k->I.reg3+")";
            pipe2 = pipe2 +aux+"\n";
            pipe3 = pipe2;
            }
                                    else if(k->I.id == Bubble){
                                    pipe2 = pipe2 +"[ "+IntToStr(k->I.idx)+" ] "+k->I.id+"\n";
                                    pipe3 = pipe2;
                                    }
                                    else if(k->I.id == "NOP") {
                                    aux = "[ "+IntToStr(k->I.idx)+" ] "+k->I.id;
                                    pipe2 = pipe2 +aux+"\n";
                                    }
                                    else if(k->I.id != "NOP" && k->I.id != Bubble) {
                                    aux = "[ "+IntToStr(k->I.idx)+" ] "+k->I.id+" "+k->I.reg1+","+k->I.reg2+","+k->I.reg3;
                                    pipe2 = pipe2 +aux+"\n";
                                    pipe3 = pipe2;
                                    }


            k = k->Dir;
            count++;

            }

}



int Lista :: Indice(String instrucao, Lista *L ){
   Nodo *x;
    String Match2;
    if ( !Vazia()){
        x = L->Primeiro->Dir;
    }
    while (x != NULL){
        if(x->I.id == "LW" || x->I.id == "lw" || x->I.id == "sw" || x->I.id == "SW"){
        Match2 = x->I.id+" "+x->I.reg1+","+x->I.reg2+"("+x->I.reg3+")";
        }
        else if(x->I.id == "NOP"){
        Match2 = x->I.id;
        }
        else{
        Match2 = x->I.id+" "+x->I.reg1+","+x->I.reg2+","+x->I.reg3;
        }
        if(Match2 != instrucao){
        x = x->Dir;
        }
        else{
         return x->I.idx;
        }

    }
}

Nodo* Lista :: BuscaPosicao (String posicao, Lista &L)
{
    Nodo *x;
    String Match;
    if ( !Vazia()){
        x = L.Primeiro->Dir;
    }
    while (x != NULL){
        if(x->I.id == "LW" || x->I.id == "lw" || x->I.id == "sw" || x->I.id == "SW"){
        Match = IntToStr(x->I.idx)+" "+x->I.id+" "+x->I.reg1+","+x->I.reg2+"("+x->I.reg3+")";
        }
        else if(x->I.id == "NOP" || x->I.id == Bubble){
        Match =  IntToStr(x->I.idx)+" "+x->I.id;
        }
        else{
        Match = IntToStr(x->I.idx)+" "+x->I.id+" "+x->I.reg1+","+x->I.reg2+","+x->I.reg3;
        }
        if(Match != posicao){
        x = x->Dir;
        }
        else{
         return x;
        }

    }


}

int Lista :: GetIndice (String posicao, Lista &L)
{
    Nodo *x;
    String Match;
    if ( !Vazia()){
        x = L.Primeiro->Dir;
    }
    while (x != NULL){
        if(x->I.id == "LW" || x->I.id == "lw" || x->I.id == "sw" || x->I.id == "SW"){
        Match = IntToStr(x->I.idx)+" "+x->I.id+" "+x->I.reg1+","+x->I.reg2+"("+x->I.reg3+")";
        }
        else if(x->I.id == "NOP" || x->I.id == Bubble){
        Match =  IntToStr(x->I.idx)+" "+x->I.id;
        }
        else{
        Match = IntToStr(x->I.idx)+" "+x->I.id+" "+x->I.reg1+","+x->I.reg2+","+x->I.reg3;
        }
        if(Match != posicao){
        x = x->Dir;
        }
        else{
         return x->I.idx;
        }

    }


}


String LEXEMA, TESTE;
bool LW_SW, FIM_DE_ARQUIVO, MONTADO =false;
int TAMANHO, linha, FLAG,z=0;
Lista *L = new Lista();
 int gg = 1;

struct RegistroLexico{

  String Tipo;
  String id;
};


//******************************************************************************



class AnalisadorLexico{

public:
        int caracter, estado,  estado_final , tamanho, i;

        Item I;
        AnsiString letra;
        RegistroLexico RL;

        AnalisadorLexico();

        void Get_RL();//retorna o registro lexico
        void SetEstado();
        void SetLexema();
        int Get_Estado();
        void SetTipo();
        String GetLexema( );


};


AnalisadorLexico::AnalisadorLexico(){//abre analisador
 linha = 1;
 i=1;
 TAMANHO = 0;
 FIM_DE_ARQUIVO = false;
 this->estado_final = 15;
 FLAG = 1;

} //fecha analisador


int AnalisadorLexico::Get_Estado()
{
 return(this->estado);
}

void AnalisadorLexico:: SetEstado()
{
 this->estado = 0;
}

void AnalisadorLexico:: SetLexema()
{
 LEXEMA = "";
}

String AnalisadorLexico :: GetLexema(){
  return LEXEMA;
}





void AnalisadorLexico :: Get_RL(){

estado =0;


do {
if(TAMANHO > LogoAppForm->RichEdit1->GetTextLen()+linha){

      FIM_DE_ARQUIVO = true;
      estado=2;
      }

letra = LogoAppForm->RichEdit1->Text.SubString(i,1);

   if(letra == "\n"){
   linha++;
   }


if(letra != "a" && letra != "b" && letra != "c" && letra != "d" && letra != "e" && letra != "f" && letra != "g"
&& letra != "h" && letra != "i" && letra != "j" && letra != "l" && letra != "k" && letra != "m" && letra != "n"
&& letra != "o" && letra != "p" && letra != "q" && letra != "r" && letra != "s" && letra != "t" && letra != "u"
&& letra != "v" && letra != "x" && letra != "y" && letra != "w" && letra != "z" && letra != "0" && letra != "1"
&& letra != "2" && letra != "3" && letra != "4" && letra != "5" && letra != "6" && letra != "7" && letra != "8"
&& letra != "9" && letra != "," && letra != "(" && letra != ")" && letra != "$" && letra != " " && letra != "�"
&& letra != "\n" && letra != "A" && letra != "B" && letra != "C" && letra != "D" && letra != "E"
&& letra != "F" && letra != "G" && letra != "H" && letra != "I" && letra != "J"
&& letra != "L" && letra != "K" && letra != "M" && letra != "N" && letra != "O"
&& letra != "P" && letra != "Q" && letra != "R" && letra != "S" && letra != "T"
&& letra != "U" && letra != "V" && letra != "X" && letra != "Y" && letra != "W"
&& letra != "Z" && letra != "\'"&& letra != "\r")

      {
           if(letra == "*" || letra == "\'" || letra == "/" || letra == "+" || letra == "-" ||
              letra == ">" || letra == "<"  || letra == "?" || letra == ":" || letra == ";" ||
              letra == "[" || letra == "]"  || letra == "{" || letra == "}" || letra == "=" ||
              letra == "'" || letra == "!"  || letra == "@" || letra == "#" || letra == "%" ||
              letra == "�" || letra == "&"  || letra == "_" || letra == "`" || letra == "�" ||
              letra == "|" ){
              ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
              LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
              LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
              Mensagem1= Mensagem1+"\n"+Linha+": "+IntToStr(linha);
              MessageBox(NULL,Mensagem1.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
              Application->ProcessMessages();
              Sleep(3000);
              exit(0);
      }

    }



    else{
        switch(estado)
        {//1
          case 0:
             if(letra == "(" || letra == ")" || letra == "," )
              {
               LEXEMA =  letra;
               estado = 2;

              }
             else if (letra == "a" || letra == "b" || letra == "c" || letra == "d" || letra == "e"
                   || letra == "f" || letra == "g" || letra == "h" || letra == "i" || letra == "j"
                   || letra == "l" || letra == "k" || letra == "m" || letra == "n" || letra == "o"
                   || letra == "p" || letra == "q" || letra == "r" || letra == "s" || letra == "t"
                   || letra == "u" || letra == "v" || letra == "x" || letra == "y" || letra == "w"
                   || letra == "z" || letra == "A" || letra == "B" || letra == "C" || letra == "D" || letra == "E"
                   || letra == "F" || letra == "G" || letra == "H" || letra == "I" || letra == "J"
                   || letra == "L" || letra == "K" || letra == "M" || letra == "N" || letra == "O"
                   || letra == "P" || letra == "Q" || letra == "R" || letra == "S" || letra == "T"
                   || letra == "U" || letra == "V" || letra == "X" || letra == "Y" || letra == "W"
                   || letra == "Z"){//SE FOR LETRA
             LEXEMA  = LEXEMA + letra;

             estado = 1;
             RL.Tipo = "INSTRUCAO";

             }
             else if(letra == "$"){
             LEXEMA  = LEXEMA + letra;
             RL.Tipo = "REGISTRADOR";
             estado = 3;

             }
             else if(letra == "0" || letra == "1" || letra == "2"
                  || letra == "3" || letra == "4" || letra == "5"
                  || letra == "6" || letra == "7" || letra == "8"
                  || letra == "9"){
             LEXEMA  = LEXEMA + letra;
             estado = 4;

             }
             else
             {
             estado=0;

             }
             break;
          //Fim Estado 0

          case 1:   //ID

          if (letra == "a" || letra == "b" || letra == "c" || letra == "d" || letra == "e"
           || letra == "f" || letra == "g" || letra == "h" || letra == "i" || letra == "j"
           || letra == "l" || letra == "k" || letra == "m" || letra == "n" || letra == "o"
           || letra == "p" || letra == "q" || letra == "r" || letra == "s" || letra == "t"
           || letra == "u" || letra == "v" || letra == "x" || letra == "y" || letra == "w"
           || letra == "z" || letra == "A" || letra == "B" || letra == "C" || letra == "D" || letra == "E"
           || letra == "F" || letra == "G" || letra == "H" || letra == "I" || letra == "J"
           || letra == "L" || letra == "K" || letra == "M" || letra == "N" || letra == "O"
           || letra == "P" || letra == "Q" || letra == "R" || letra == "S" || letra == "T"
           || letra == "U" || letra == "V" || letra == "X" || letra == "Y" || letra == "W"
           || letra == "Z"){ //
           LEXEMA = LEXEMA + letra;
           estado = 1;

           }
          else{
            estado = 2;

           }
          break;
         //Fim estado 1
          case 2:
           estado = 2;
           //("CASE 2");
              break;
          //Fim Estado 2
          case 3:
               if(letra == "a" || letra == "b" || letra == "c" || letra == "d" || letra == "e"
               || letra == "f" || letra == "g" || letra == "h" || letra == "i" || letra == "j"
               || letra == "l" || letra == "k" || letra == "m" || letra == "n" || letra == "o"
               || letra == "p" || letra == "q" || letra == "r" || letra == "s" || letra == "t"
               || letra == "u" || letra == "v" || letra == "x" || letra == "y" || letra == "w"
               || letra == "z" || letra == "0" || letra == "1" || letra == "2" || letra == "3"
               || letra == "4" || letra == "5" || letra == "6" || letra == "7" || letra == "8"
               || letra == "9" || letra == "A" || letra == "B" || letra == "C" || letra == "D" || letra == "E"
               || letra == "F" || letra == "G" || letra == "H" || letra == "I" || letra == "J"
               || letra == "L" || letra == "K" || letra == "M" || letra == "N" || letra == "O"
               || letra == "P" || letra == "Q" || letra == "R" || letra == "S" || letra == "T"
               || letra == "U" || letra == "V" || letra == "X" || letra == "Y" || letra == "W"
               || letra == "Z" || letra == "\r"){
                 if(letra == "\r"){
                 if(I.id == "LW" || I.id == "lw" || I.id == "SW" || I.id == "sw" && (LogoAppForm->RichEdit1->Text.SubString(i-1,1) != ")")){
                 ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
                 LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
                 LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
                 Mensagem6= Mensagem6+"\n"+Linha+": "+IntToStr(linha);
                 MessageBox(NULL,Mensagem6.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
                 Application->ProcessMessages();
                 Sleep(3000);
                 exit(0);
                 }
                 estado = 3;
                 }
                 else{
                 LEXEMA = LEXEMA + letra;
                 estado = 3;
                 RL.Tipo = "REGISTRADOR";
                 }

                 }
                 else if(letra == ","){

                 i--;
                 TAMANHO--;
                 estado=2;
                 }
                 else if(letra == ")"){
                 i--;
                 TAMANHO--;
                 estado=2;
                 } 
                 else if(letra == "\n"){
                 i =i-2;
                 TAMANHO--;
                 linha--;
                 estado=2;
                 }
                 else if(letra == " "){
                 ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
                 LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
                 LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
                 Mensagem4= Mensagem4+"\n"+Linha+": "+IntToStr(linha);
                 MessageBox(NULL,Mensagem4.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
                 Application->ProcessMessages();
                 Sleep(3000);
                 exit(0);
                 }
                 else{
                 estado = 2;

                 RL.Tipo = "REGISTRADOR";

                 }

          break;
          //Fim Estado 3


         case 4:
              if(letra == "0" || letra == "1" || letra == "2"
              || letra == "3" || letra == "4" || letra == "5"
              || letra == "6" || letra == "7" || letra == "8"
              || letra == "9")    // 'numero
              {
               LEXEMA = LEXEMA + letra;
               estado = 4;
               RL.Tipo = "ENDERECO";

              }
              else if(letra == "("){
              i--;
              TAMANHO--;
              estado=2;
              }
              else{

              estado = 2;

              }

         break;
         }//switch

      }
   TAMANHO++;
   i++;

 }while(this->estado!= 2);

TESTE = GetLexema( );

 if(TESTE != "(" && TESTE != ")" && TESTE != ","){

        if(FLAG == 1){
         I.id = TESTE;


         }
                 else if(FLAG == 2){
                 I.reg1 = TESTE;


                 }
                         else if(FLAG == 3){
                         I.reg2 = TESTE;


                         }
                                 else if(FLAG == 4){
                                 I.reg3 = TESTE;
                                 FLAG = 0;
                                 L->Inserir(I);
                                 MONTADO = true;
                                 }
                                 FLAG++;

    }

 RL.id = GetLexema( );

 SetEstado();//depois q reconhece o token setar no LEX o Estado 0
 SetLexema(); //depois q reconhece o token setar no LEX o string " "



}

//******************************************************************************



class AnalisadorSintatico{

public:
        AnalisadorSintatico(AnalisadorLexico &LEX);
        void CasaToken(String Token_Esperado);
        void I(void);
        void R(void);
        void S(void);
        void C(void);




//Objetos e ponteiros


        AnalisadorLexico *LEX;
        String Lexema;

private:
        String Token_Corrente;
        int posicao;
        int tamanho;
        String Tokens;
        RegistroLexico RL;




};



AnalisadorSintatico::AnalisadorSintatico(AnalisadorLexico &LEX)
{
  LW_SW = false;
  this->LEX = &LEX;
  LEX.Get_RL();
  Token_Corrente = LEX.RL.id;
  S();

}

void AnalisadorSintatico :: CasaToken(String Token_Esperado)
{

 if(Token_Esperado == Token_Corrente)
   {

      LEX->Get_RL();
      this->Token_Corrente = LEX->RL.id;


   }

 else{
      if(BarraR == true){
      linha--;
      }

        ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
        LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
        LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
        Mensagem2= Mensagem2+"\n"+Linha+": "+IntToStr(linha);
        MessageBox(NULL,Mensagem2.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
        Application->ProcessMessages();
        Sleep(3000);
        exit(0);
      }//if


}


void AnalisadorSintatico :: S(void)
{

   do{
     LW_SW = false;
     I();
     R();
     Tokens = Tokens+" - "+LEX->RL.id;
     CasaToken(",");
     if(LEX->RL.Tipo == "REGISTRADOR"){
        if(LW_SW == true){
        ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
        LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
        LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
        Mensagem2= Mensagem2+"\n"+Linha+": "+IntToStr(linha);
        MessageBox(NULL,Mensagem2.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
        Application->ProcessMessages();
        Sleep(3000);
        exit(0);
        }

     R();
     Tokens = Tokens+" - "+LEX->RL.id;
     CasaToken(",");
     R();
     }
     else if(LEX->RL.Tipo == "ENDERECO"){
                if(LW_SW == false){
                ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
                LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
                LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
                Mensagem2= Mensagem2+"\n"+Linha+": "+IntToStr(linha);
                MessageBox(NULL,Mensagem2.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
                Application->ProcessMessages();
                Sleep(3000);
                exit(0);
                }

        C();
        }

   }while(this->Token_Corrente == "add" || this->Token_Corrente == "sub" || this->Token_Corrente == "mul"
       || this->Token_Corrente == "div" || this->Token_Corrente == "lw"  || this->Token_Corrente == "and"
       || this->Token_Corrente == "or"  || this->Token_Corrente == "xor" || this->Token_Corrente == "sw"
       || this->Token_Corrente == "bne" || this->Token_Corrente == "beq" || this->Token_Corrente == "ADD"
       || this->Token_Corrente == "SUB" || this->Token_Corrente == "MUL"
       || this->Token_Corrente == "DIV" || this->Token_Corrente == "LW"  || this->Token_Corrente == "AND"
       || this->Token_Corrente == "OR"  || this->Token_Corrente == "XOR" || this->Token_Corrente == "SW"
       || this->Token_Corrente == "BNE" || this->Token_Corrente == "BEQ");


   if(this->Token_Corrente != "add" && this->Token_Corrente != "sub" && this->Token_Corrente !="mul"
   && this->Token_Corrente != "div" && this->Token_Corrente != "lw"  && this->Token_Corrente !="and"
   && this->Token_Corrente != "or"  && this->Token_Corrente != "xor" && this->Token_Corrente != "sw"
   && this->Token_Corrente != "bne" && this->Token_Corrente != "beq" && this->Token_Corrente != "ADD"
   && this->Token_Corrente != "SUB" && this->Token_Corrente !="MUL"
   && this->Token_Corrente != "DIV" && this->Token_Corrente != "LW"  && this->Token_Corrente !="AND"
   && this->Token_Corrente != "OR"  && this->Token_Corrente != "XOR" && this->Token_Corrente != "SW"
   && this->Token_Corrente != "BNE" && this->Token_Corrente != "BEQ" && FIM_DE_ARQUIVO == false){

        ErrLinha = LogoAppForm->RichEdit1->Perform(EM_LINEFROMCHAR, linha, 0);  //selecionar linha
        LogoAppForm->RichEdit1->SelStart  =  LogoAppForm->RichEdit1->Perform(EM_LINEINDEX, linha-1, 0);
        LogoAppForm->RichEdit1->SelLength = LogoAppForm->RichEdit1->Lines->Strings[ErrLinha].Length()-2;
        Mensagem2= Mensagem2+"\n"+Linha+": "+IntToStr(linha);
        MessageBox(NULL,Mensagem2.c_str(), "Ultimate Pipeline Simulator", MB_ICONERROR );
        Application->ProcessMessages();
        Sleep(3000);
        exit(0);

   }

   L->Dependencias(L);
   L->UnidadeControle(L);

}



void AnalisadorSintatico :: I(void)
{


  Tokens = Tokens+" - "+LEX->RL.id;
 if (this->Token_Corrente == "add" || Token_Corrente == "ADD"){
     CasaToken(Token_Corrente);
     }
    else if (this->Token_Corrente == "sub" || Token_Corrente == "SUB"){
          CasaToken(Token_Corrente);
          }
         else if (this->Token_Corrente == "mul" || Token_Corrente == "MUL"){
              CasaToken(Token_Corrente);
             }
             else if(this->Token_Corrente == "div" || Token_Corrente == "DIV"){
                    CasaToken(Token_Corrente);
                 }
                 else if(this->Token_Corrente == "lw" || Token_Corrente == "LW"){
                 LW_SW = true;
                    CasaToken(Token_Corrente);

                 }
                           else if(this->Token_Corrente == "and" || Token_Corrente == "AND"){
                           CasaToken(Token_Corrente);
                           }
                                else if(this->Token_Corrente == "or" || Token_Corrente == "OR"){
                                CasaToken(Token_Corrente);
                                }
                                         else if(this->Token_Corrente == "xor" || Token_Corrente == "XOR"){
                                         CasaToken(Token_Corrente);
                                         }
                                            else if(this->Token_Corrente == "sw" || Token_Corrente == "SW"){
                                            LW_SW = true;
                                            CasaToken(Token_Corrente);
                                            }
                                                     else if(this->Token_Corrente == "bne" || Token_Corrente == "BNE"){
                                                     CasaToken(Token_Corrente);
                                                     }
                                                        else if(this->Token_Corrente == "beq" || Token_Corrente == "BEQ"){
                                                        CasaToken(Token_Corrente);
                                                        }
                                         else{
                                            CasaToken("id");
                                         }

}     //fim proc T

void AnalisadorSintatico :: R(void)
{
Tokens = Tokens+" - "+LEX->RL.id;
    if(LEX->RL.Tipo == "REGISTRADOR"){
     CasaToken(LEX->RL.id);
     }
}     //fim proc T

void AnalisadorSintatico :: C(void)
{
Tokens = Tokens+" - "+LEX->RL.id;

     CasaToken(Token_Corrente);
     Tokens = Tokens+" - "+LEX->RL.id;
     CasaToken("(");
     R();
     Tokens = Tokens+" - "+LEX->RL.id;
     CasaToken(")");

}     //fim proc T


class Compilador{


private:
AnalisadorLexico      *LEX;
AnalisadorSintatico   *SIM;


public:
 Begin();

};

 Compilador :: Begin(){
 LEX = new AnalisadorLexico();
 SIM = new AnalisadorSintatico(*LEX);

}

Nodo *Temp, *Temp2,*Temp3;



class T1 : public TThread
{
private:
protected:
        void __fastcall Execute();
        void __fastcall Display(Lista *L);
public:
        __fastcall T1(bool CreateSuspended);
};

//---------------------------------------------------------------------------
//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall T1::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
__fastcall T1::T1(bool CreateSuspended)
        : TThread(CreateSuspended)
{

}
//---------------------------------------------------------------------------
void __fastcall T1::Execute()
{

Display(L);

}
void __fastcall T1 :: Display(Lista *L){

Priority = tpTimeCritical;
FreeOnTerminate = true;


bool BEGIN = true;
maxi=0;

  LogoAppForm->Edit2->Enabled = false;
  LogoAppForm->Edit3->Enabled = false;

  Temp  = L->Primeiro->Dir;
  Temp2 = L->Primeiro;
  pos = 0;
  CClock = 1;
  BBolhas = 0;

        while(maxi < L->tamanho){

       if(Temp == L->Ultimo){
       LogoAppForm->Button3->Enabled = false;
       }


          if(LogoAppForm->TrackBar1->Position == 0){
Velocidade = 2000;
}
else if(LogoAppForm->TrackBar1->Position == 1){
Velocidade = 1500;
}
else if(LogoAppForm->TrackBar1->Position == 2){
Velocidade = 1000;
}
else if(LogoAppForm->TrackBar1->Position == 3){
Velocidade = 500;
}
else if(LogoAppForm->TrackBar1->Position == 4){
Velocidade = 250;
}


         Application->ProcessMessages();
         Sleep(Velocidade);

         LogoAppForm->Label9->Caption = CClock;

        if(Temp != NULL){

        while(Temp->I.id == Bubble){
        Temp = Temp->Dir;

        }

        if(Temp->I.id != Bubble && Temp->I.id != "NOP" && Temp2->I.id != Bubble){
          if(Temp->I.id == "LW" || Temp->I.id == "lw" || Temp->I.id == "sw" || Temp->I.id == "SW"){
          LogoAppForm->Label22->Caption = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+"("+Temp->I.reg3+")";

        }
        else{
        LogoAppForm->Label22->Caption = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+","+Temp->I.reg3;

        }

        }


        if(maxi >= 2){
         if(BEGIN == true){
         Temp2 = L->Primeiro->Dir;

         LogoAppForm->Button5->Enabled = true;
         }
         pos++;
         BEGIN = false;
         if(Temp2 == L->Primeiro->Dir->Dir){
         LogoAppForm->Button3->Enabled = true;
         }

        LogoAppForm->Edit8->Text = LogoAppForm->Edit7->Text;
        LogoAppForm->Edit7->Text = LogoAppForm->Edit6->Text;

        LogoAppForm->Image10->Visible = false;
        LogoAppForm->Image11->Visible = false;
        LogoAppForm->Image12->Visible = false;
        LogoAppForm->Image13->Visible = false;
        LogoAppForm->Image14->Visible = false;
        LogoAppForm->Image15->Visible = false;
        LogoAppForm->Image16->Visible = false;
        LogoAppForm->Image17->Visible = false;
        LogoAppForm->Image18->Visible = false;



        if(Temp2->I.id == "lw" || Temp2->I.id == "LW" || Temp2->I.id == "sw" || Temp2->I.id == "SW" && maxi > 2 ){

                                 LogoAppForm->Edit6->Text = Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+"("+Temp2->I.reg3+")";
                                 local2 = IntToStr(pos)+" "+Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+"("+Temp2->I.reg3+")";
                                 }
                                    else if(Temp2->I.id == Bubble){
                                    LogoAppForm->Edit6->Text = Temp2->I.id;
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    sndPlaySound("bolha.wav",SND_ASYNC);
                                    BBolhas++;
                                    LogoAppForm->Label10->Caption = BBolhas;
                                    }
                                    else if(Temp2->I.id == "NOP"){
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    LogoAppForm->Edit6->Text = Temp2->I.id;
                                    }

                                    else {
                                    local2 = IntToStr(pos)+" "+Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+","+Temp2->I.reg3;
                                    LogoAppForm->Edit6->Text = Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+","+Temp2->I.reg3;

                                    }
                                    if(Temp2->I.add1On == "ON" && LogoAppForm->Edit6->Text != Bubble){
                                        LogoAppForm->Image13->Visible = true;
                                        LogoAppForm->Image14->Visible = true;
                                        LogoAppForm->Image15->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                        if(Temp2->I.add2On == "ON" && LogoAppForm->Edit6->Text != Bubble){
                                        LogoAppForm->Image10->Visible = true;
                                        LogoAppForm->Image11->Visible = true;
                                        LogoAppForm->Image12->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                       if(maxi > 2){
                                        if(Temp2->Esq->Esq->I.add3On == "ON" && (Temp2->Esq->I.id == "SW" || Temp2->Esq->I.id== "sw") && LogoAppForm->Edit7->Text != Bubble){
                                        LogoAppForm->Image16->Visible = true;
                                        LogoAppForm->Image17->Visible = true;
                                        LogoAppForm->Image18->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                        }


        }

                          if(Temp2->I.id == Bubble){


                          }else
                                 if(Temp->I.id == "lw" || Temp->I.id == "LW" || Temp->I.id == "sw" || Temp->I.id == "SW" && maxi > 2 ){
                                 LogoAppForm->Edit5->Text = LogoAppForm->Edit4->Text;
                                 local = IntToStr(L->Indice(LogoAppForm->Edit5->Text,L))+" "+LogoAppForm->Edit5->Text;
                                 LogoAppForm->Edit4->Text = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+"("+Temp->I.reg3+")";

                                 }
                                    else if(Temp->I.id != "NOP"){
                                    LogoAppForm->Edit5->Text = LogoAppForm->Edit4->Text;
                                    local = IntToStr(L->Indice(LogoAppForm->Edit5->Text,L))+" "+LogoAppForm->Edit5->Text;
                                    LogoAppForm->Edit4->Text = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+","+Temp->I.reg3;

                                    }
                                    else if(Temp->I.id == "NOP"){
                                    LogoAppForm->Edit5->Text = LogoAppForm->Edit4->Text;
                                    LogoAppForm->Edit4->Text = Temp->I.id;
                                    local = IntToStr(Temp->I.idx)+" "+LogoAppForm->Edit4->Text;

                                    }




        }

        if(Temp != NULL && Temp2->I.id != Bubble){
        Temp = Temp->Dir;
        }//fim if 4
        if(maxi >= 2 && Temp2 != NULL){
        Temp2 = Temp2->Dir;
        }
     maxi++;
     if(Temp2->Dir != L->Ultimo->Esq){
     CClock++;
     }
     LogoAppForm->CGauge1->AddProgress(100/(L->tamanho));
   } // fim while
   LogoAppForm->CGauge1->AddProgress(100/(L->tamanho));



  Temp  = L->Primeiro->Dir;
  Temp2 = L->Primeiro;
  CClock =0;
  BBolhas=0;

LogoAppForm->Edit4->Text = "NOP";
LogoAppForm->Edit5->Text = "NOP";
LogoAppForm->Edit6->Text = "NOP";
LogoAppForm->Edit7->Text = "NOP";
LogoAppForm->Edit8->Text = "NOP";

if(maxi == L->tamanho){
LogoAppForm->ToolButton7->Enabled = true;
 }
 else{
 LogoAppForm->ToolButton7->Enabled = false;
 }

  LogoAppForm->Button4->Enabled = true;
  LogoAppForm->Edit2->Enabled   = true;
  LogoAppForm->Edit3->Enabled   = true;
  LogoAppForm->Button1->Enabled = false;
  LogoAppForm->Button2->Enabled = false;
  LogoAppForm->Button3->Enabled = false;
  LogoAppForm->Button5->Enabled = false;
  LogoAppForm->Button6->Enabled = false;

  LogoAppForm->CheckBox1->Enabled = true;
  LogoAppForm->CheckBox2->Enabled = true;
  LogoAppForm->CheckBox3->Enabled = true;
  LogoAppForm->Linguagem1->Enabled = true;
  Terminate();
  CClock = 1;
}





class T2 : public TThread
{
private:
protected:
        void __fastcall Execute();
        void __fastcall Display2(Lista *L);
public:
        __fastcall T2(bool CreateSuspended);
};

//---------------------------------------------------------------------------
//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall T1::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
__fastcall T2::T2(bool CreateSuspended)
        : TThread(CreateSuspended)
{

}
//---------------------------------------------------------------------------
void __fastcall T2::Execute()
{

Display2(L);

}
void __fastcall T2 :: Display2(Lista *L){
Priority = tpTimeCritical;
FreeOnTerminate = true;
 
   pos = L->GetIndice(local2, *L);

   Temp =  L->BuscaPosicao(local,*L);
   Temp2 = L->BuscaPosicao(local2,*L);
   Temp3 = Temp2->Esq->Esq->Esq;

   if(Temp2->I.id == Bubble){
   BBolhas--;
   LogoAppForm->Label10->Caption = BBolhas;
   }

   Temp2 = Temp2->Esq;

   if(Temp->I.id == "NOP"){
   Temp = Temp->Esq->Esq;
   }else{

   if(Temp->Dir->I.id != Bubble){

   if(LogoAppForm->Edit6->Text != Bubble){
           Temp = Temp->Esq;
           }

     }
     else{

       if(LogoAppForm->Edit6->Text == Bubble){
           Temp = Temp->Dir;
           }
           else{

      if(L->tamanho > 7){
           if(Temp->Esq->I.id == Bubble && Temp->Esq->Esq->I.id == Bubble){
           Temp = Temp->Esq;
           }
           else if(LogoAppForm->Edit6->Text != Bubble){
           Temp = Temp->Esq;
           }
           else if(Temp->Esq->I.id != Bubble && Temp->Esq->Esq->I.id == Bubble){
           Temp = Temp->Esq->Esq;
           }


           }

      }
    }
  }
   while(Temp3 != NULL){


         if(Temp3 == L->Primeiro->Dir){
         LogoAppForm->Button1->Enabled = false;
         }

         LogoAppForm->Label9->Caption = CClock;

        if(Temp != NULL){

        while(Temp->I.id == Bubble){
        Temp = Temp->Esq;
        }
         pos--;
         if(CClock < 7){
         LogoAppForm->Button1->Enabled = false;
        }

         if(Temp3->I.id == "lw" || Temp3->I.id == "LW" || Temp3->I.id == "sw" || Temp3->I.id == "SW" && maxi > 2 ){
                                 LogoAppForm->Edit7->Text = LogoAppForm->Edit8->Text;
                                 LogoAppForm->Edit8->Text = Temp3->I.id+" "+Temp3->I.reg1+","+Temp3->I.reg2+"("+Temp3->I.reg3+")";

                                 }
                                    else if(Temp3->I.id == Bubble){
                                    LogoAppForm->Edit7->Text = LogoAppForm->Edit8->Text;
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    LogoAppForm->Edit8->Text = Temp3->I.id;

                                    }
                                    else if(Temp3->I.id == "NOP"){
                                    LogoAppForm->Edit7->Text = LogoAppForm->Edit8->Text;
                                    LogoAppForm->Edit8->Text = Temp3->I.id;

                                    }

                                    else {
                                    LogoAppForm->Edit7->Text = LogoAppForm->Edit8->Text;
                                    LogoAppForm->Edit8->Text = Temp3->I.id+" "+Temp3->I.reg1+","+Temp3->I.reg2+","+Temp3->I.reg3;


                                    }


        LogoAppForm->Image10->Visible = false;
        LogoAppForm->Image11->Visible = false;
        LogoAppForm->Image12->Visible = false;
        LogoAppForm->Image13->Visible = false;
        LogoAppForm->Image14->Visible = false;
        LogoAppForm->Image15->Visible = false;
        LogoAppForm->Image16->Visible = false;
        LogoAppForm->Image17->Visible = false;
        LogoAppForm->Image18->Visible = false;

        if(Temp2->I.id == "lw" || Temp2->I.id == "LW" || Temp2->I.id == "sw" || Temp2->I.id == "SW" && maxi > 2 ){

                                 LogoAppForm->Edit6->Text = Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+"("+Temp2->I.reg3+")";
                                 local2 = IntToStr(pos)+" "+Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+"("+Temp2->I.reg3+")";
                                 }
                                    else if(Temp2->I.id == Bubble){
                                    LogoAppForm->Edit6->Text = Temp2->I.id;
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    sndPlaySound("bolha.wav",SND_ASYNC);

                                    LogoAppForm->Label10->Caption = BBolhas;
                                    }
                                    else if(Temp2->I.id == "NOP"){
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    LogoAppForm->Edit6->Text = Temp2->I.id;
                                    }

                                    else {
                                    local2 = IntToStr(pos)+" "+Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+","+Temp2->I.reg3;
                                    LogoAppForm->Edit6->Text = Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+","+Temp2->I.reg3;

                                    }
                                    if(Temp2->I.add1On == "ON" && LogoAppForm->Edit6->Text != Bubble){
                                        LogoAppForm->Image13->Visible = true;
                                        LogoAppForm->Image14->Visible = true;
                                        LogoAppForm->Image15->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                        if(Temp2->I.add2On == "ON" && LogoAppForm->Edit6->Text != Bubble){
                                        LogoAppForm->Image10->Visible = true;
                                        LogoAppForm->Image11->Visible = true;
                                        LogoAppForm->Image12->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                       if(maxi > 2){
                                        if(Temp2->Esq->Esq->I.add3On == "ON" && (Temp2->Esq->I.id == "SW" || Temp2->Esq->I.id== "sw") && LogoAppForm->Edit7->Text != Bubble){
                                        LogoAppForm->Image16->Visible = true;
                                        LogoAppForm->Image17->Visible = true;
                                        LogoAppForm->Image18->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                        }




                          if(Temp2->Dir->I.id == Bubble){


                          }else


                                 if(Temp->I.id == "lw" || Temp->I.id == "LW" || Temp->I.id == "sw" || Temp->I.id == "SW" && maxi > 2 ){

                                 LogoAppForm->Edit4->Text = LogoAppForm->Edit5->Text;
                                 local = IntToStr(L->Indice(LogoAppForm->Edit4->Text,L))+" "+LogoAppForm->Edit5->Text;
                                 LogoAppForm->Edit5->Text = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+"("+Temp->I.reg3+")";

                                 }
                                  else if(Temp->I.id != "NOP"){

                                    LogoAppForm->Edit4->Text = LogoAppForm->Edit5->Text;
                                    local = IntToStr(L->Indice(LogoAppForm->Edit4->Text,L))+" "+LogoAppForm->Edit5->Text;
                                    LogoAppForm->Edit5->Text = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+","+Temp->I.reg3;

                                    }
                                    else if(Temp->I.id == "NOP"){

                                    LogoAppForm->Edit4->Text = LogoAppForm->Edit5->Text;
                                    LogoAppForm->Edit5->Text = Temp->I.id;
                                    local = IntToStr(Temp->I.idx)+" "+LogoAppForm->Edit4->Text;

                                    }


                                     LogoAppForm->Label22->Caption = LogoAppForm->Edit4->Text; //instru��o atual

        }

        if(Temp != NULL && Temp2->I.id != Bubble){
        Temp = Temp->Esq;
        }
        if(maxi >= 2 && Temp2 != NULL){
        Temp2 = Temp2->Esq;
        }
        if(maxi >= 2 && Temp3 != NULL){
        Temp3 = Temp3->Esq;
        }
     maxi--;
       
     LogoAppForm->Label9->Caption = CClock;
      if(Temp2->Dir->Dir->I.id == Bubble){
      BBolhas--;
      LogoAppForm->Label10->Caption = BBolhas;
     }
     CClock--;
     LogoAppForm->Label9->Caption = CClock;
     LogoAppForm->CGauge1->AddProgress(-(100/L->tamanho));
     Suspend();
   } // fim while



}


class T3 : public TThread
{
private:
protected:
        void __fastcall Execute();
        void __fastcall Display3(Lista *L);
public:
        __fastcall T3(bool CreateSuspended);
};

//---------------------------------------------------------------------------
//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall T1::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
__fastcall T3::T3(bool CreateSuspended)
        : TThread(CreateSuspended)
{

}
//---------------------------------------------------------------------------
void __fastcall T3::Execute()
{
Display3(L);
}
void __fastcall T3 :: Display3(Lista *L){

Priority = tpTimeCritical;
FreeOnTerminate = true;


   Temp =  L->BuscaPosicao(local,*L);
   Temp2 = L->BuscaPosicao(local2,*L);
   if(L->tamanho > 7){

                   if(Temp->Dir->I.id == Bubble && Temp->Dir->Dir->I.id == Bubble){
                   Temp = Temp->Dir->Dir;

                   }
                   else if(Temp->Dir->I.id != Bubble && Temp->Dir->Dir->I.id == Bubble){
                   Temp = Temp->Dir;
                   }

   }
           if(Temp->Dir->I.id != Bubble && Temp->Dir->Dir->I.id != Bubble && LogoAppForm->Edit6->Text == Bubble){
           Temp = Temp->Dir;
           }
           else if(Temp->Dir->I.id != Bubble && Temp->Dir->Dir->I.id != Bubble && LogoAppForm->Edit6->Text != Bubble){
           Temp = Temp->Dir->Dir;
           }
           else if(Temp->I.id == Bubble && Temp->Dir->I.id != Bubble && LogoAppForm->Edit6->Text != Bubble){
           Temp = Temp->Dir->Dir;
           }
           else if(Temp->I.id == Bubble && Temp->Dir->I.id != Bubble && LogoAppForm->Edit6->Text == Bubble){
           Temp = Temp->Dir->Dir;
           }

   Temp2 = Temp2->Dir;
   if(LogoAppForm->Edit6->Text == Bubble){
   Temp = Temp->Dir;
   }


  if(Temp2 == L->Primeiro->Dir->Dir){
           if(Temp->Dir->I.id == Bubble && Temp->Dir->Dir->I.id == Bubble){
           Temp = Temp->Dir->Dir;
           }
           else if(Temp->Dir->I.id != Bubble && Temp->Dir->Dir->I.id == Bubble){
           Temp = Temp->Dir;
           }
  }
  

        while(maxi < L->tamanho){


         LogoAppForm->Label9->Caption = CClock;

        if(Temp != NULL){

        while(Temp->I.id == Bubble){
        Temp = Temp->Dir;

        }
        if(Temp2->I.idx > 3){
        LogoAppForm->Button1->Enabled = true;
        }
        if(Temp->I.id != Bubble && Temp->I.id != "NOP" && Temp2->I.id != Bubble){
          if(Temp->I.id == "LW" || Temp->I.id == "lw" || Temp->I.id == "sw" || Temp->I.id == "SW"){
        LogoAppForm->Label22->Caption = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+"("+Temp->I.reg3+")";

        }
        else{
        LogoAppForm->Label22->Caption = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+","+Temp->I.reg3;

        }

        }




        pos++;
        LogoAppForm->Edit8->Text = LogoAppForm->Edit7->Text;
        LogoAppForm->Edit7->Text = LogoAppForm->Edit6->Text;

        LogoAppForm->Image10->Visible = false;
        LogoAppForm->Image11->Visible = false;
        LogoAppForm->Image12->Visible = false;
        LogoAppForm->Image13->Visible = false;
        LogoAppForm->Image14->Visible = false;
        LogoAppForm->Image15->Visible = false;
        LogoAppForm->Image16->Visible = false;
        LogoAppForm->Image17->Visible = false;
        LogoAppForm->Image18->Visible = false;



        if(Temp2->I.id == "lw" || Temp2->I.id == "LW" || Temp2->I.id == "sw" || Temp2->I.id == "SW" ){

                                 LogoAppForm->Edit6->Text = Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+"("+Temp2->I.reg3+")";
                                 local2 = IntToStr(pos)+" "+Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+"("+Temp2->I.reg3+")";
                                 }
                                    else if(Temp2->I.id == Bubble){
                                    LogoAppForm->Edit6->Text = Temp2->I.id;
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    sndPlaySound("bolha.wav",SND_ASYNC);
                                    BBolhas++;
                                    LogoAppForm->Label10->Caption = BBolhas;
                                    }
                                    else if(Temp2->I.id == "NOP"){
                                    local2 = IntToStr(pos)+" "+Temp2->I.id;
                                    LogoAppForm->Edit6->Text = Temp2->I.id;
                                    }

                                    else {
                                    local2 = IntToStr(pos)+" "+Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+","+Temp2->I.reg3;
                                    LogoAppForm->Edit6->Text = Temp2->I.id+" "+Temp2->I.reg1+","+Temp2->I.reg2+","+Temp2->I.reg3;

                                    }
                                     if(Temp2->I.add1On == "ON" && LogoAppForm->Edit6->Text != Bubble){
                                        LogoAppForm->Image13->Visible = true;
                                        LogoAppForm->Image14->Visible = true;
                                        LogoAppForm->Image15->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                        if(Temp2->I.add2On == "ON" && LogoAppForm->Edit6->Text != Bubble){
                                        LogoAppForm->Image10->Visible = true;
                                        LogoAppForm->Image11->Visible = true;
                                        LogoAppForm->Image12->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                       if(maxi > 2){
                                        if(Temp2->Esq->Esq->I.add3On == "ON" && (Temp2->Esq->I.id == "SW" || Temp2->Esq->I.id== "sw") && LogoAppForm->Edit7->Text != Bubble){
                                        LogoAppForm->Image16->Visible = true;
                                        LogoAppForm->Image17->Visible = true;
                                        LogoAppForm->Image18->Visible = true;

                                        Application->ProcessMessages();
                                        Sleep(100);
                                        }
                                        }




                          if(Temp2->I.id == Bubble){


                          }else
                                 if(Temp->I.id == "lw" || Temp->I.id == "LW" || Temp->I.id == "sw" || Temp->I.id == "SW" ){
                                 LogoAppForm->Edit5->Text = LogoAppForm->Edit4->Text;
                                 local = IntToStr(L->Indice(LogoAppForm->Edit5->Text,L))+" "+LogoAppForm->Edit5->Text;
                                 LogoAppForm->Edit4->Text = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+"("+Temp->I.reg3+")";

                                 }
                                   else if(Temp->I.id != "NOP"){
                                    LogoAppForm->Edit5->Text = LogoAppForm->Edit4->Text;
                                    local = IntToStr(L->Indice(LogoAppForm->Edit5->Text,L))+" "+LogoAppForm->Edit5->Text;
                                    LogoAppForm->Edit4->Text = Temp->I.id+" "+Temp->I.reg1+","+Temp->I.reg2+","+Temp->I.reg3;

                                    }
                                    else if(Temp->I.id == "NOP"){
                                    LogoAppForm->Edit5->Text = LogoAppForm->Edit4->Text;

                                    LogoAppForm->Edit4->Text = Temp->I.id;
                                    local = IntToStr(Temp->I.idx)+" "+LogoAppForm->Edit4->Text;

                                    }




        }

        if(Temp != NULL && Temp2->I.id != Bubble){
        Temp = Temp->Dir;
        }
        if(Temp2 != NULL){
        Temp2 = Temp2->Dir;
        }
        maxi++;
        LogoAppForm->Label9->Caption = CClock;
         if(Temp2->Dir != L->Ultimo->Esq){
         CClock++;
         }
       
        LogoAppForm->CGauge1->AddProgress(100/(L->tamanho));
        Suspend();

      if(maxi == L->tamanho-1){
      LogoAppForm->CGauge1->AddProgress(100/(L->tamanho));
      LogoAppForm->Button2->Enabled = false;
      LogoAppForm->ToolButton7->Enabled = true;

  LogoAppForm->Button4->Enabled = true;
  LogoAppForm->Edit2->Enabled   = true;
  LogoAppForm->Edit3->Enabled   = true;
  LogoAppForm->Button1->Enabled = false;
  LogoAppForm->Button2->Enabled = false;
  LogoAppForm->Button3->Enabled = false;
  LogoAppForm->Button5->Enabled = false;
  LogoAppForm->Button6->Enabled = false;
  LogoAppForm->Edit8->Text = "NOP";

  LogoAppForm->CheckBox1->Enabled = true;
  LogoAppForm->CheckBox2->Enabled = true;
  LogoAppForm->CheckBox3->Enabled = true;
  LogoAppForm->Linguagem1->Enabled = true;
  LogoAppForm->Button1->Enabled = false;
  Terminate();
 }
 else{
 LogoAppForm->ToolButton7->Enabled = false;
 }
   } // fim while
 LogoAppForm->Button1->Enabled = false;
 L = new Lista();
}



T1 *Thread1 = new T1(true);
T2 *Thread2 = new T2(true);
T3 *Thread3 = new T3(true);

TLogoAppForm *LogoAppForm;
bool linguagemBR = true;


//---------------------------------------------------------------------------

__fastcall TLogoAppForm::TLogoAppForm(TComponent *Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::FileNew1Execute(TObject *Sender)
{
	FFileName = LoadStr(sUntitled);
	RichEdit1->Lines->Clear();
	RichEdit1->Modified = false;
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::FileOpen1Execute(TObject *Sender)
{
	if (OpenDialog->Execute())
	{
		RichEdit1->Lines->LoadFromFile(OpenDialog->FileName);
		FFileName = OpenDialog->FileName;
		RichEdit1->SetFocus();
		RichEdit1->Modified = false;
		RichEdit1->ReadOnly = OpenDialog->Options.Contains(ofReadOnly);
	}
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::FileSave1Execute(TObject *Sender)
{
        if(RichEdit1->GetTextLen()== 0){
         MessageBox(NULL,Mensagem3.c_str(), "Ultimate Pipeline Simulator", MB_ICONWARNING );

        }
	if (FFileName == LoadStr(sUntitled))
		FileSaveAs1Execute(Sender);
	else
	{

        AnsiString str;
	TVarRec vrs[1];

	if (SaveDialog->Execute())
	{
		if (FileExists(SaveDialog->FileName))
		{
			str = FmtLoadStr(sOverwrite, OPENARRAY(TVarRec, (SaveDialog->FileName)));
			if (MessageDlg(str, mtConfirmation, TMsgDlgButtons() << mbYes << mbNo <<
				mbCancel, 0) != IDYES)
				return;
		}
		RichEdit1->Lines->SaveToFile(SaveDialog->FileName);
		FFileName = SaveDialog->FileName;
		RichEdit1->Modified = false;
	}
	}
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::FileSaveAs1Execute(TObject *Sender)
{
	AnsiString str;
	TVarRec vrs[1];

	if (SaveDialog->Execute())
	{
		if (FileExists(SaveDialog->FileName))
		{
			str = FmtLoadStr(sOverwrite, OPENARRAY(TVarRec, (SaveDialog->FileName)));
			if (MessageDlg(str, mtConfirmation, TMsgDlgButtons() << mbYes << mbNo <<
				mbCancel, 0) != IDYES)
				return;
		}
		RichEdit1->Lines->SaveToFile(SaveDialog->FileName);
		FFileName = SaveDialog->FileName;
		RichEdit1->Modified = false;
	}
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::FileSend1Execute(TObject *Sender)
{
	TMapiMessage MapiMessage;
	Cardinal MError;

	MapiMessage.ulReserved = 0;
	MapiMessage.lpszSubject = NULL;
	MapiMessage.lpszNoteText = RichEdit1->Lines->Text.c_str();
	MapiMessage.lpszMessageType = NULL;
	MapiMessage.lpszDateReceived = NULL;
	MapiMessage.lpszConversationID = NULL;
	MapiMessage.flFlags = 0;
	MapiMessage.lpOriginator = NULL;
	MapiMessage.nRecipCount = 0;
	MapiMessage.lpRecips = NULL;
	MapiMessage.nFileCount = 0;
	MapiMessage.lpFiles = NULL;

	MError = MapiSendMail(0, 0, MapiMessage, MAPI_DIALOG | MAPI_LOGON_UI |
		MAPI_NEW_SESSION, 0);

	if (MError)
		MessageDlg(LoadStr(sSendError), mtError, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::FileExit1Execute(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::HelpAbout1Execute(TObject *Sender)
{
if(linguagemBR == true){
AboutBox->ProductName->Caption = "Programa:";
AboutBox->Version->Caption = "Vers�o:";
AboutBox->Comments->Caption = "Sobre:";
AboutBox->Copyright->Caption = "Autor:";
AboutBox->Label4->Caption = "Este simulador � destinado a uso acad�mico, de forma";
AboutBox->Label5->Caption = "a ajudar o aprendizado dos alunos na disciplina";
AboutBox->Label6->Caption = "Arquitetura de Computadores.";
}
else{
AboutBox->ProductName->Caption = "Program:";
AboutBox->Version->Caption = "Version:";
AboutBox->Comments->Caption = "About:";
AboutBox->Copyright->Caption = "Author:";
AboutBox->Label4->Caption = "This simulator is intended for academic use";
AboutBox->Label5->Caption = "help the learning of students in the discipline";
AboutBox->Label6->Caption = "of Computer Architecture.";
}
AboutBox->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::PortugusBR1Click(TObject *Sender)
{
GroupBox1->Caption = "Instru��es ";
GroupBox2->Caption = "Par�metros ";
GroupBox3->Caption = "Recursos ";
GroupBox4->Caption = "Simula��o ";
Label1->Caption = "Tempo de ciclo [ Processador Monociclo ]";
Label2->Caption = "Tempo de ciclo [ Processador Pipeline ]";
Form1->Label1->Caption = "Tempo de ciclo [ Processador Monociclo ]";
Form1->Label2->Caption = "Tempo de ciclo [ Processador Pipeline ]";
Form1->Label7->Caption = "Tempo de ciclo [ Processador Monociclo ]";
Form1->Label8->Caption = "Tempo de ciclo [ Processador Pipeline ]";
Form1->Label10->Caption = "Ciclos na execu��o: ";
Form1->Label12->Caption = "Bolhas: ";
Form1->Label16->Caption = "N� de Dependencias RAW: ";
Form1->Label14->Caption = "Adiantamento(s) Ativado(s): ";
Form1->GroupBox4->Caption = " Estat�sticas ";
Form1->MainMenu1->Items->Caption = "Relat�rio";
Form1->Imprimir1->Caption = "Imprimir";
Form1->Salvar1->Caption = "Salvar para [.Doc]";
Form1->Sair1->Caption = "Sair";
Label7->Caption = "Ciclo: ";
Label8->Caption = "Bolhas: ";
Label12->Caption = "Progresso:";
Label21->Caption = "Intru��o atual:";
CheckBox1->Caption = "Adiantamento [ MEM -> EX ]";
CheckBox2->Caption = "Adiantamento [ ER -> EX ]";
CheckBox3->Caption = "Adiantamento [ ER -> MEM ]";
Form1->GroupBox1->Caption = " Sa�da ";
Form1->GroupBox2->Caption = " Depend�ncias RAW ";
File1->Caption = "Arquivo";
FileNewItem->Caption = "Novo";
FileOpenItem->Caption = "Abrir";
FileSaveItem->Caption = "Salvar";
FileSaveAsItem->Caption = "Salvar Como";
FileExitItem->Caption = "Sair";
Linha = "Linha";
Linguagem1->Caption = "Linguagem";
Help1->Caption = "Sobre";
HelpAboutItem->Caption = "Sobre...";
Editt->Caption = "Editar";
CutItem->Caption = "Recortar";
CopyItem->Caption = "Copiar";
PasteItem->Caption = "Colar";
GroupBox6->Caption = " BI ";
GroupBox7->Caption = " DI ";
GroupBox8->Caption = " EX ";
GroupBox9->Caption = " MEM ";
GroupBox10->Caption = " ER ";
Button3->Caption = "Pausar";
Button4->Caption = "Executar";
Button5->Caption = "Parar";
Label5->Caption = "Velocidade:";
AboutBox->Version->Caption = "Vers�o:";
AboutBox->Comments->Caption = "Sobre:";
AboutBox->Copyright->Caption = "Autor:";
SemiTitulo = "Relat�rio Final";
rodape = "Fim do relat�rio.";
adiantamentos = "Nenhum adiantamento foi ativado!";
Continuar = "Continuar";
Button6->Caption = Continuar;
Mensagem1 = "Erro L�xico no c�digo Assembler!";
Mensagem2 = "Erro Sint�tico no c�digo Assembler!";
Mensagem3 = "Aten��o, arquivo em branco.";
Mensagem4 = "Erro! Registrador sem identificador ou formato inv�lido.";
Mensagem5 = "Aten��o! Somente digitos.";
Mensagem6 = "Erro Sint�tico! Instru��o (LW ou SW) faltando ')'";
Mensagem7 = "";
Mensagem8 = "";
Bubble = "BOLHA";


}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::EnglishUS1Click(TObject *Sender)
{
linguagemBR = false;
GroupBox1->Caption = "Instructions ";
GroupBox2->Caption = "Parameters ";
GroupBox3->Caption = "Features ";
GroupBox4->Caption = "Simulation ";
Form1->GroupBox1->Caption = " Output ";
Form1->GroupBox2->Caption = " RAW Dependencies ";
Form1->Label1->Caption = "Cycle time [Processor unicycles]";
Form1->Label2->Caption = "Cycle time [Processor Pipeline]";
Form1->Label7->Caption = "Cycle time [Processor unicycles]";
Form1->Label8->Caption = "Cycle time [Processor Pipeline]";
Form1->GroupBox4->Caption = " Statistics ";
Form1->Label10->Caption = "Cycles in the execution: ";
Form1->Label12->Caption = "Stalls: ";
Form1->Label16->Caption = "N� of RAW dependencies: ";
Form1->Label14->Caption = "Forwarding On: ";
Form1->Relatrio1->Caption = "Report";
Form1->Imprimir1->Caption = "Print";
Form1->Salvar1->Caption = "Save to [.Doc]";
Form1->Sair1->Caption = "Close";
Label1->Caption = "Cycle time [Processor unicycles]";
Label2->Caption = "Cycle time [Processor Pipeline]";
Label7->Caption = "Cycle: ";
Label8->Caption = "Stalls: ";
Label12->Caption = "Progress:";
Label21->Caption = "Current instruction:";
CheckBox1->Caption = "Forwarding [ MEM -> EX ]";
CheckBox2->Caption = "Forwarding [ WB -> EX ]";
CheckBox3->Caption = "Forwarding [ WB -> MEM ]";
File1->Caption = "File";
FileNewItem->Caption = "New";
FileOpenItem->Caption = "Open";
FileSaveItem->Caption = "Save";
FileSaveAsItem->Caption = "Save As";
FileExitItem->Caption = "Exit";
Linha = "Line";
Linguagem1->Caption = "Language";
Help1->Caption = "About";
HelpAboutItem->Caption = "About...";
Editt->Caption = "Edit";
CutItem->Caption = "Cut";
CopyItem->Caption = "Copy";
PasteItem->Caption = "Paste";
GroupBox6->Caption = " IF ";
GroupBox7->Caption = " ID ";
GroupBox8->Caption = " EX ";
GroupBox9->Caption = " MEM ";
GroupBox10->Caption = " WB ";
Button3->Caption = "Pause";
Button4->Caption = "Execute";
Button5->Caption = "Stop";
Label5->Caption = "Speed:";
AboutBox->Version->Caption = "Version:";
AboutBox->Comments->Caption = "About:";
AboutBox->Copyright->Caption = "Copyright:";
SemiTitulo = "Final Report";
rodape = "End of Report.";
adiantamentos = "No forwarding was enabled!";
Continuar = "Continue";
Button6->Caption = Continuar;
Mensagem1 = "Lexicon error in the Assembly code!";
Mensagem2 = "Syntactic error in the Assembly code!";
Mensagem3 = "Attention, blank file.";
Mensagem4 = "Error! Recorder Without identifier or invalid format.";
Mensagem5 = "Attention, only digits.";
Mensagem6 = "Syntactic error! Instruction (LW or SW) missing ')'";
Mensagem7 = "";
Mensagem8 = "";
Bubble = "STALL";

}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::TrackBar1Change(TObject *Sender)
{
if(TrackBar1->Position == 0){
Label6->Caption = "20%";
}
else if(TrackBar1->Position == 1){
Label6->Caption = "40%";
}
else if(TrackBar1->Position == 2){
Label6->Caption = "60%";
}
else if(TrackBar1->Position == 3){
Label6->Caption = "80%";
}
else if(TrackBar1->Position == 4){
Label6->Caption = "100%";
}
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::Button4Click(TObject *Sender)
{
L = new Lista();
Thread1 = new T1(true);
Thread2 = new T2(true);
Thread3 = new T3(true);

Temp = new Nodo();
Temp2 = new Nodo();
flag_counter =0;
mode ="AUTO";

LogoAppForm->CGauge1->Progress = 0;
LogoAppForm->Button4->Enabled = false;
LogoAppForm->ToolButton7->Enabled = false;
LogoAppForm->Linguagem1->Enabled = false;
LogoAppForm->CheckBox1->Enabled = false;
LogoAppForm->CheckBox2->Enabled = false;
LogoAppForm->CheckBox3->Enabled = false;

if(LogoAppForm->CheckBox1->Checked == true){
  Image1->Visible = true;
  Image2->Visible = true;
  Image3->Visible = true;
 }
 else{
  Image1->Visible = false;
  Image2->Visible = false;
  Image3->Visible = false;
 }

 if(LogoAppForm->CheckBox2->Checked == true){
  Image4->Visible = true;
  Image5->Visible = true;
  Image6->Visible = true;
 }
 else{
  Image4->Visible = false;
  Image5->Visible = false;
  Image6->Visible = false;
 }

 if(LogoAppForm->CheckBox3->Checked == true){
  Image7->Visible = true;
  Image8->Visible = true;
  Image9->Visible = true;
 }
 else{
  Image7->Visible = false;
  Image8->Visible = false;
  Image9->Visible = false;
 }


LogoAppForm->Label9->Caption = "0";
LogoAppForm->Label10->Caption = "0";

        if(Edit2->Text != "0" && Edit3->Text != "0"
        && Edit2->Text != "" && Edit2->Text != " " && Edit2->Text != "  "
        && Edit2->Text != "   " && Edit2->Text != "    " && Edit3->Text != ""
        && Edit3->Text != " " && Edit3->Text != "  " && Edit3->Text != "   " && Edit3->Text != "    " ){// falta barrar letras e caracters
        Compilador *C = new Compilador();
        C->Begin();

   Item NOP;
   NOP.id = "NOP";
   while(w<5){
   L->InserePosicao(L->Ultimo,*L,NOP);
   w++;
   }
   L->ReIndexar(L);

   Thread1->Resume();

   w=0;


}
else{
     MessageBox(NULL,"Por favor, preencha os campos 'Tempo de Ciclo' antes de iniciar sua simula��o.\nAten��o os valores n�o podem ser 0(zero).", "Ultimate Pipeline Simulator", MB_ICONERROR );
     LogoAppForm->Button4->Enabled = true;
     }






}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::ToolButton7Click(TObject *Sender)
{
int  count = 0,i=0;
float SpeedUp = 0.0;
LogoAppForm->ToolButton7->Enabled = false;


                LogoAppForm->Button5->Enabled = false;
                LogoAppForm->Button3->Enabled = false;
                LogoAppForm->Button2->Enabled = false;
                LogoAppForm->Button1->Enabled = false;


                AnsiString Impressora, Saida, Montagem= "         ", Montagem2;
 if(!StrToFloat(LogoAppForm->Edit2->Text) || !StrToFloat(LogoAppForm->Edit3->Text)){


 }

SpeedUp = (StrToFloat(LogoAppForm->Edit2->Text))*((L->tamanho)-(L->BolhasRAW))/((StrToFloat(LogoAppForm->Edit3->Text))*(L->ciclos+1));

Form1->Label9->Caption = FormatFloat("0.000", SpeedUp);
Form1->RichEdit1->Text = L->pipe3;
Form1->RichEdit2->Text = L->SDependencias;
Form1->Label3->Caption = LogoAppForm->Edit2->Text+" ns";
Form1->Label4->Caption = LogoAppForm->Edit3->Text+" ns";
Form1->Label13->Caption = L->BolhasRAW;
Form1->Label11->Caption = L->ciclos;
Form1->Label17->Caption = L->NUMDEP;


if(LogoAppForm->CheckBox1->Checked == true){
Form1->Label15->Caption = "[ MEM -> EX ]";
}
if( LogoAppForm->CheckBox2->Checked == true){
Form1->Label15->Caption = Form1->Label15->Caption+"[ ER -> EX ]";
}
if( LogoAppForm->CheckBox3->Checked == true){
Form1->Label15->Caption = Form1->Label15->Caption+"[ ER -> MEM ]";
}
if(LogoAppForm->CheckBox1->Checked == false && LogoAppForm->CheckBox2->Checked == false && LogoAppForm->CheckBox3->Checked == false){
Form1->Label15->Caption = adiantamentos;
}

Impressora = "\n\n\t\t\t\t\t\tULTIMATE PIPELINE SIMULATOR\n\t\t\t\t\t\t\t       "+SemiTitulo+"\n\n\n\n\n";
Impressora = Impressora+"\n          "+Form1->Label10->Caption+Form1->Label11->Caption;
Impressora = Impressora+"\n          "+Form1->Label12->Caption+Form1->Label13->Caption;
Impressora = Impressora+"\n          "+Form1->Label14->Caption+Form1->Label15->Caption;
Impressora = Impressora+"\n          "+Form1->Label16->Caption+Form1->Label17->Caption;
Impressora = Impressora+"\n          SpeedUp: "+Form1->Label9->Caption;
while(count < Form1->RichEdit1->Lines->Count){

Montagem = Montagem+Form1->RichEdit1->Lines->Strings[count]+"         ";
count++;
}

Montagem2 = Montagem2+"          ";
while(i < Form1->RichEdit2->Lines->Count){

Montagem2 = Montagem2+Form1->RichEdit2->Lines->Strings[i]+"          ";
i++;
}

Impressora = Impressora+"\n\n         "+Form1->GroupBox1->Caption+"\n\n"+Montagem+"\n\n\n"+"         "+Form1->GroupBox2->Caption+"\n\n"+Montagem2+"\n\t\t\t\t\t\t\t\t\t\t"+rodape;



Form1->RichEdit3->Text = Impressora;


Form1->ShowModal();


LogoAppForm->Image1->Visible = false;
LogoAppForm->Image2->Visible = false;
LogoAppForm->Image3->Visible = false;
LogoAppForm->Image4->Visible = false;
LogoAppForm->Image5->Visible = false;
LogoAppForm->Image6->Visible = false;
LogoAppForm->Image7->Visible = false;
LogoAppForm->Image8->Visible = false;
LogoAppForm->Image9->Visible = false;
L->~Lista();
L->tamanho = 0;
Form1->Label15->Caption = "";
L = new Lista();
LogoAppForm->Button4->Enabled = true;


  LogoAppForm->Edit2->Enabled = true;
  LogoAppForm->Edit3->Enabled = true;

}
//---------------------------------------------------------------------------


void __fastcall TLogoAppForm::Button5Click(TObject *Sender)
{
Thread1->Suspend();
Thread2->Suspend();
Thread3->Suspend();
Thread1->Terminate();
Thread2->Terminate();
Thread3->Terminate();
L->tamanho =0;
LogoAppForm->Edit4->Text = "NOP";
LogoAppForm->Edit5->Text = "NOP";
LogoAppForm->Edit6->Text = "NOP";
LogoAppForm->Edit7->Text = "NOP";
LogoAppForm->Edit8->Text = "NOP";
L = new Lista();
LogoAppForm->Button4->Enabled = true;

LogoAppForm->Image1->Enabled = false;
LogoAppForm->Image2->Enabled = false;
LogoAppForm->Image3->Enabled = false;

LogoAppForm->Image4->Enabled = false;
LogoAppForm->Image5->Enabled = false;
LogoAppForm->Image6->Enabled = false;

LogoAppForm->Image7->Enabled = false;
LogoAppForm->Image8->Enabled = false;
LogoAppForm->Image9->Enabled = false;

LogoAppForm->Image10->Enabled = false;
LogoAppForm->Image11->Enabled = false;
LogoAppForm->Image12->Enabled = false;

LogoAppForm->Image13->Enabled = false;
LogoAppForm->Image14->Enabled = false;
LogoAppForm->Image15->Enabled = false;

LogoAppForm->Image16->Enabled = false;
LogoAppForm->Image17->Enabled = false;
LogoAppForm->Image18->Enabled = false;

  LogoAppForm->Button4->Enabled = true;
  LogoAppForm->Edit2->Enabled   = true;
  LogoAppForm->Edit3->Enabled   = true;
  LogoAppForm->Button5->Enabled = false;
  LogoAppForm->Button3->Enabled = false;

  LogoAppForm->CheckBox1->Enabled = true;
  LogoAppForm->CheckBox2->Enabled = true;
  LogoAppForm->CheckBox3->Enabled = true;
  LogoAppForm->Linguagem1->Enabled = true;

}
//---------------------------------------------------------------------------



void __fastcall TLogoAppForm::Button3Click(TObject *Sender)
{
if(CClock > 6){
Button1->Enabled = true;
}
Button2->Enabled = true;
Thread1->Suspend();
Button3->Enabled = false;
Button6->Enabled = true;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------




void __fastcall TLogoAppForm::Button1Click(TObject *Sender)
{

if(Direcao != "TRAS" && flag_counter != 1 ){
CClock--;
}
mode = "STEP";
flag_counter = 1;
Thread1->Terminate();
Thread3->Terminate();
Thread3 = new T3(true);
Thread2->Resume();
Button3->Enabled = false;
Button6->Enabled = false;
Direcao = "TRAS";
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::Button2Click(TObject *Sender)
{

if(Direcao != "FRENTE" && mode != "AUTO" && flag_counter != 1 ){
CClock++;
}
if(Direcao != "FRENTE" && mode == "STEP" && flag_counter == 1 ){
CClock++;
}
mode = "STEP";
flag_counter = 2;
Thread1->Terminate();
Thread2->Terminate();
Thread2 = new T2(true);
Thread3->Resume();
Button3->Enabled = false;
Button6->Enabled = false;
Direcao = "FRENTE";
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------



void __fastcall TLogoAppForm::Button6Click(TObject *Sender)
{
Button1->Enabled = false;
Button2->Enabled = false;
Thread1->Resume();
Button6->Enabled = false;
Button3->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::Edit3KeyPress(TObject *Sender, char &Key)
{

if(Key  !=   '0' && Key  !=   '1' && Key  !=   '2' && Key  !=   '3' && Key !=    '4' &&
   Key  !=   '5' && Key  !=   '6' && Key  !=   '7' && Key  !=   '8' && Key  !=   '9' &&
   Key  !=   ','){

               MessageBox(NULL,Mensagem5.c_str(), "Ultimate Pipeline Simulator", MB_ICONWARNING );
               APAGAR3 = true;
               }

}
//---------------------------------------------------------------------------


void __fastcall TLogoAppForm::Edit2KeyPress(TObject *Sender, char &Key)
{

if(Key  !=   '0' && Key  !=   '1' && Key  !=   '2' && Key  !=   '3' && Key !=    '4' &&
   Key  !=   '5' && Key  !=   '6' && Key  !=   '7' && Key  !=   '8' && Key  !=   '9' &&
   Key  !=   ','){

               MessageBox(NULL,Mensagem5.c_str(), "Ultimate Pipeline Simulator", MB_ICONWARNING );
               APAGAR2 = true;
               }

}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::Edit3Change(TObject *Sender)
{
if(APAGAR3 == true){
Edit3->Text = "";
}
APAGAR3 = false;
}
//---------------------------------------------------------------------------

void __fastcall TLogoAppForm::Edit2Change(TObject *Sender)
{
if(APAGAR2 == true){
Edit2->Text = "";
}
APAGAR2 = false;
}
//---------------------------------------------------------------------------


