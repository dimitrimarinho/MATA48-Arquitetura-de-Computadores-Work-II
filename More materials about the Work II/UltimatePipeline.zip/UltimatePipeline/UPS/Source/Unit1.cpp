//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Imprimir1Click(TObject *Sender)
{
Form1->RichEdit3->Print(Form1->RichEdit3->Text);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Sair1Click(TObject *Sender)
{
Close();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Salvar1Click(TObject *Sender)
{
int  count = 0,i=0;
float SpeedUp = 0.0;
String SemiTitulo = "Relat�rio Final", rodape = "Fim do relat�rio.", adiantamentos = "Nenhum adiantamento foi ativado!";
AnsiString Impressora, Saida, Montagem, Montagem2;


Impressora = "\n\n\t\t\t     ULTIMATE PIPELINE SIMULATOR\n\t\t\t\t         "+SemiTitulo+"\n\n\n\n\n";
Impressora = Impressora+"\n"+Form1->Label10->Caption+Form1->Label11->Caption;
Impressora = Impressora+"\n"+Form1->Label12->Caption+Form1->Label13->Caption;
Impressora = Impressora+"\n"+Form1->Label14->Caption+Form1->Label15->Caption;
Impressora = Impressora+"\n"+Form1->Label16->Caption+Form1->Label17->Caption;
Impressora = Impressora+"\nSpeedUp: "+Form1->Label9->Caption;
while(count < Form1->RichEdit1->Lines->Count){

Montagem = Montagem+Form1->RichEdit1->Lines->Strings[count];
count++;
}


while(i < Form1->RichEdit2->Lines->Count){

Montagem2 = Montagem2+Form1->RichEdit2->Lines->Strings[i];
i++;
}

Impressora = Impressora+"\n\n"+Form1->GroupBox1->Caption+"\n\n"+Montagem+"\n\n\n"+Form1->GroupBox2->Caption+"\n\n"+Montagem2+"\n\t\t\t\t\t\t\t\t\t\t"+rodape;



Form1->RichEdit4->Text = Impressora;




	AnsiString str;
	TVarRec vrs[1];


	if (Form1->SaveDialog1->Execute())
	{
		if (FileExists(Form1->SaveDialog1->FileName))
		{
			str = FmtLoadStr(1, OPENARRAY(TVarRec, (Form1->SaveDialog1->FileName)));
			if (MessageDlg(str, mtConfirmation, TMsgDlgButtons() << mbYes << mbNo <<
				mbCancel, 0) != IDYES)
				return;
		}
		RichEdit4->Lines->SaveToFile(Form1->SaveDialog1->FileName+".doc");
		Form1->SaveDialog1->FileName = Form1->SaveDialog1->FileName;
		RichEdit4->Modified = false;
	}
}
//---------------------------------------------------------------------------


